export interface Account {
  id: string;
  name: string;
  type: 'Asset' | 'Liability' | 'Income' | 'Expense' | 'Equity';
  subType: string;
  balance: number;
  createdAt: Date;
}

export interface Party {
  id: string;
  name: string;
  type: 'Customer' | 'Supplier';
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
  balance: number;
  createdAt: Date;
}

export interface Transaction {
  id: string;
  date: Date;
  voucherType: 'Payment' | 'Receipt' | 'Sales' | 'Purchase' | 'Journal' | 'Contra';
  voucherNumber: string;
  description: string;
  amount: number;
  debitAccount: string;
  creditAccount: string;
  partyId?: string;
  reference?: string;
  createdAt: Date;
}

export interface InventoryItem {
  id: string;
  name: string;
  unit: string;
  quantity: number;
  rate: number;
  value: number;
  reorderLevel: number;
  createdAt: Date;
}