import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { Account, Party, Transaction, InventoryItem } from '../types';

interface AppState {
  accounts: Account[];
  parties: Party[];
  transactions: Transaction[];
  inventory: InventoryItem[];
}

type AppAction =
  | { type: 'ADD_ACCOUNT'; payload: Account }
  | { type: 'UPDATE_ACCOUNT'; payload: Account }
  | { type: 'DELETE_ACCOUNT'; payload: string }
  | { type: 'ADD_PARTY'; payload: Party }
  | { type: 'UPDATE_PARTY'; payload: Party }
  | { type: 'DELETE_PARTY'; payload: string }
  | { type: 'ADD_TRANSACTION'; payload: Transaction }
  | { type: 'UPDATE_TRANSACTION'; payload: Transaction }
  | { type: 'DELETE_TRANSACTION'; payload: string }
  | { type: 'ADD_INVENTORY_ITEM'; payload: InventoryItem }
  | { type: 'UPDATE_INVENTORY_ITEM'; payload: InventoryItem }
  | { type: 'DELETE_INVENTORY_ITEM'; payload: string };

const initialState: AppState = {
  accounts: [
    {
      id: '1',
      name: 'Cash in Hand',
      type: 'Asset',
      subType: 'Current Asset',
      balance: 50000,
      createdAt: new Date()
    },
    {
      id: '2',
      name: 'Bank Account',
      type: 'Asset',
      subType: 'Current Asset',
      balance: 150000,
      createdAt: new Date()
    },
    {
      id: '3',
      name: 'Sales Revenue',
      type: 'Income',
      subType: 'Direct Income',
      balance: 0,
      createdAt: new Date()
    },
    {
      id: '4',
      name: 'Office Expenses',
      type: 'Expense',
      subType: 'Indirect Expense',
      balance: 0,
      createdAt: new Date()
    }
  ],
  parties: [
    {
      id: '1',
      name: 'ABC Corporation',
      type: 'Customer',
      contactPerson: 'John Smith',
      phone: '+1-555-0123',
      email: 'john@abccorp.com',
      address: '123 Business St, City, State 12345',
      balance: 25000,
      createdAt: new Date()
    },
    {
      id: '2',
      name: 'XYZ Suppliers',
      type: 'Supplier',
      contactPerson: 'Sarah Johnson',
      phone: '+1-555-0456',
      email: 'sarah@xyzsuppliers.com',
      address: '456 Industrial Ave, City, State 67890',
      balance: -15000,
      createdAt: new Date()
    }
  ],
  transactions: [],
  inventory: [
    {
      id: '1',
      name: 'Office Supplies',
      unit: 'Pack',
      quantity: 50,
      rate: 25,
      value: 1250,
      reorderLevel: 10,
      createdAt: new Date()
    }
  ]
};

const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case 'ADD_ACCOUNT':
      return { ...state, accounts: [...state.accounts, action.payload] };
    case 'UPDATE_ACCOUNT':
      return {
        ...state,
        accounts: state.accounts.map(acc =>
          acc.id === action.payload.id ? action.payload : acc
        )
      };
    case 'DELETE_ACCOUNT':
      return {
        ...state,
        accounts: state.accounts.filter(acc => acc.id !== action.payload)
      };
    case 'ADD_PARTY':
      return { ...state, parties: [...state.parties, action.payload] };
    case 'UPDATE_PARTY':
      return {
        ...state,
        parties: state.parties.map(party =>
          party.id === action.payload.id ? action.payload : party
        )
      };
    case 'DELETE_PARTY':
      return {
        ...state,
        parties: state.parties.filter(party => party.id !== action.payload)
      };
    case 'ADD_TRANSACTION':
      return { ...state, transactions: [...state.transactions, action.payload] };
    case 'UPDATE_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.map(txn =>
          txn.id === action.payload.id ? action.payload : txn
        )
      };
    case 'DELETE_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.filter(txn => txn.id !== action.payload)
      };
    case 'ADD_INVENTORY_ITEM':
      return { ...state, inventory: [...state.inventory, action.payload] };
    case 'UPDATE_INVENTORY_ITEM':
      return {
        ...state,
        inventory: state.inventory.map(item =>
          item.id === action.payload.id ? action.payload : item
        )
      };
    case 'DELETE_INVENTORY_ITEM':
      return {
        ...state,
        inventory: state.inventory.filter(item => item.id !== action.payload)
      };
    default:
      return state;
  }
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};