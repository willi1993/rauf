import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BarChart3, Download, FileText, TrendingUp, TrendingDown } from 'lucide-react';

const FinancialReports: React.FC = () => {
  const { state } = useApp();
  const [activeReport, setActiveReport] = useState('balance-sheet');

  const generateBalanceSheet = () => {
    const assets = state.accounts.filter(acc => acc.type === 'Asset');
    const liabilities = state.accounts.filter(acc => acc.type === 'Liability');
    const equity = state.accounts.filter(acc => acc.type === 'Equity');
    
    const totalAssets = assets.reduce((sum, acc) => sum + acc.balance, 0);
    const totalLiabilities = liabilities.reduce((sum, acc) => sum + acc.balance, 0);
    const totalEquity = equity.reduce((sum, acc) => sum + acc.balance, 0);
    
    return { assets, liabilities, equity, totalAssets, totalLiabilities, totalEquity };
  };

  const generateProfitLoss = () => {
    const income = state.accounts.filter(acc => acc.type === 'Income');
    const expenses = state.accounts.filter(acc => acc.type === 'Expense');
    
    const totalIncome = income.reduce((sum, acc) => sum + acc.balance, 0);
    const totalExpenses = expenses.reduce((sum, acc) => sum + acc.balance, 0);
    const netProfit = totalIncome - totalExpenses;
    
    return { income, expenses, totalIncome, totalExpenses, netProfit };
  };

  const generateCashFlow = () => {
    const cashAccounts = state.accounts.filter(acc => 
      acc.name.toLowerCase().includes('cash') || acc.name.toLowerCase().includes('bank')
    );
    
    const operatingCash = state.transactions
      .filter(txn => txn.voucherType === 'Sales' || txn.voucherType === 'Purchase')
      .reduce((sum, txn) => sum + (txn.voucherType === 'Sales' ? txn.amount : -txn.amount), 0);
    
    const investingCash = state.transactions
      .filter(txn => txn.voucherType === 'Journal')
      .reduce((sum, txn) => sum + txn.amount, 0);
    
    const financingCash = state.transactions
      .filter(txn => txn.voucherType === 'Payment' || txn.voucherType === 'Receipt')
      .reduce((sum, txn) => sum + (txn.voucherType === 'Receipt' ? txn.amount : -txn.amount), 0);
    
    return { cashAccounts, operatingCash, investingCash, financingCash };
  };

  const balanceSheet = generateBalanceSheet();
  const profitLoss = generateProfitLoss();
  const cashFlow = generateCashFlow();

  const exportReport = (reportType: string) => {
    let csvContent = '';
    let filename = '';

    switch (reportType) {
      case 'balance-sheet':
        csvContent = [
          ['BALANCE SHEET'],
          [''],
          ['ASSETS'],
          ...balanceSheet.assets.map(acc => [acc.name, acc.balance]),
          ['Total Assets', balanceSheet.totalAssets],
          [''],
          ['LIABILITIES'],
          ...balanceSheet.liabilities.map(acc => [acc.name, acc.balance]),
          ['Total Liabilities', balanceSheet.totalLiabilities],
          [''],
          ['EQUITY'],
          ...balanceSheet.equity.map(acc => [acc.name, acc.balance]),
          ['Total Equity', balanceSheet.totalEquity]
        ].map(row => row.join(',')).join('\n');
        filename = 'balance_sheet.csv';
        break;
      
      case 'profit-loss':
        csvContent = [
          ['PROFIT & LOSS STATEMENT'],
          [''],
          ['INCOME'],
          ...profitLoss.income.map(acc => [acc.name, acc.balance]),
          ['Total Income', profitLoss.totalIncome],
          [''],
          ['EXPENSES'],
          ...profitLoss.expenses.map(acc => [acc.name, acc.balance]),
          ['Total Expenses', profitLoss.totalExpenses],
          [''],
          ['NET PROFIT/LOSS', profitLoss.netProfit]
        ].map(row => row.join(',')).join('\n');
        filename = 'profit_loss.csv';
        break;
    }

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const reports = [
    { id: 'balance-sheet', label: 'Balance Sheet', icon: BarChart3 },
    { id: 'profit-loss', label: 'Profit & Loss', icon: TrendingUp },
    { id: 'cash-flow', label: 'Cash Flow', icon: TrendingDown },
    { id: 'trial-balance', label: 'Trial Balance', icon: FileText }
  ];

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Financial Reports</h2>
          <p className="text-gray-600 mt-1">Generate comprehensive financial statements</p>
        </div>
        <button
          onClick={() => exportReport(activeReport)}
          className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Export Report</span>
        </button>
      </div>

      {/* Report Navigation */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <div className="flex flex-wrap gap-2">
          {reports.map((report) => {
            const Icon = report.icon;
            return (
              <button
                key={report.id}
                onClick={() => setActiveReport(report.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all ${
                  activeReport === report.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{report.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Report Content */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        {activeReport === 'balance-sheet' && (
          <div className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6 text-center">
              BALANCE SHEET
            </h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Assets */}
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-4 bg-blue-50 p-3 rounded-lg">
                  ASSETS
                </h4>
                <div className="space-y-2">
                  {balanceSheet.assets.map((asset) => (
                    <div key={asset.id} className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-700">{asset.name}</span>
                      <span className="font-medium text-gray-900">
                        ${asset.balance.toLocaleString()}
                      </span>
                    </div>
                  ))}
                  <div className="flex justify-between py-3 border-t-2 border-blue-200 bg-blue-50 px-3 rounded-lg font-bold text-blue-900">
                    <span>Total Assets</span>
                    <span>${balanceSheet.totalAssets.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Liabilities & Equity */}
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-4 bg-red-50 p-3 rounded-lg">
                  LIABILITIES
                </h4>
                <div className="space-y-2 mb-6">
                  {balanceSheet.liabilities.map((liability) => (
                    <div key={liability.id} className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-700">{liability.name}</span>
                      <span className="font-medium text-gray-900">
                        ${liability.balance.toLocaleString()}
                      </span>
                    </div>
                  ))}
                  <div className="flex justify-between py-3 border-t-2 border-red-200 bg-red-50 px-3 rounded-lg font-bold text-red-900">
                    <span>Total Liabilities</span>
                    <span>${balanceSheet.totalLiabilities.toLocaleString()}</span>
                  </div>
                </div>

                <h4 className="text-lg font-semibold text-gray-900 mb-4 bg-purple-50 p-3 rounded-lg">
                  EQUITY
                </h4>
                <div className="space-y-2">
                  {balanceSheet.equity.map((equity) => (
                    <div key={equity.id} className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-700">{equity.name}</span>
                      <span className="font-medium text-gray-900">
                        ${equity.balance.toLocaleString()}
                      </span>
                    </div>
                  ))}
                  <div className="flex justify-between py-3 border-t-2 border-purple-200 bg-purple-50 px-3 rounded-lg font-bold text-purple-900">
                    <span>Total Equity</span>
                    <span>${balanceSheet.totalEquity.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeReport === 'profit-loss' && (
          <div className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6 text-center">
              PROFIT & LOSS STATEMENT
            </h3>
            <div className="max-w-2xl mx-auto">
              {/* Income */}
              <div className="mb-8">
                <h4 className="text-lg font-semibold text-gray-900 mb-4 bg-green-50 p-3 rounded-lg">
                  INCOME
                </h4>
                <div className="space-y-2">
                  {profitLoss.income.map((income) => (
                    <div key={income.id} className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-700">{income.name}</span>
                      <span className="font-medium text-gray-900">
                        ${income.balance.toLocaleString()}
                      </span>
                    </div>
                  ))}
                  <div className="flex justify-between py-3 border-t-2 border-green-200 bg-green-50 px-3 rounded-lg font-bold text-green-900">
                    <span>Total Income</span>
                    <span>${profitLoss.totalIncome.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Expenses */}
              <div className="mb-8">
                <h4 className="text-lg font-semibold text-gray-900 mb-4 bg-orange-50 p-3 rounded-lg">
                  EXPENSES
                </h4>
                <div className="space-y-2">
                  {profitLoss.expenses.map((expense) => (
                    <div key={expense.id} className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-700">{expense.name}</span>
                      <span className="font-medium text-gray-900">
                        ${expense.balance.toLocaleString()}
                      </span>
                    </div>
                  ))}
                  <div className="flex justify-between py-3 border-t-2 border-orange-200 bg-orange-50 px-3 rounded-lg font-bold text-orange-900">
                    <span>Total Expenses</span>
                    <span>${profitLoss.totalExpenses.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Net Profit/Loss */}
              <div className={`p-4 rounded-lg border-2 ${
                profitLoss.netProfit >= 0 
                  ? 'bg-green-50 border-green-200' 
                  : 'bg-red-50 border-red-200'
              }`}>
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold text-gray-900">NET PROFIT/LOSS</span>
                  <span className={`text-xl font-bold ${
                    profitLoss.netProfit >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    ${Math.abs(profitLoss.netProfit).toLocaleString()}
                    {profitLoss.netProfit >= 0 ? ' (Profit)' : ' (Loss)'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeReport === 'cash-flow' && (
          <div className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6 text-center">
              CASH FLOW STATEMENT
            </h3>
            <div className="max-w-2xl mx-auto space-y-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="text-lg font-semibold text-blue-900 mb-2">Operating Activities</h4>
                <div className="flex justify-between">
                  <span className="text-gray-700">Net Cash from Operations</span>
                  <span className={`font-bold ${
                    cashFlow.operatingCash >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    ${cashFlow.operatingCash.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="bg-purple-50 p-4 rounded-lg">
                <h4 className="text-lg font-semibold text-purple-900 mb-2">Investing Activities</h4>
                <div className="flex justify-between">
                  <span className="text-gray-700">Net Cash from Investments</span>
                  <span className={`font-bold ${
                    cashFlow.investingCash >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    ${cashFlow.investingCash.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="bg-orange-50 p-4 rounded-lg">
                <h4 className="text-lg font-semibold text-orange-900 mb-2">Financing Activities</h4>
                <div className="flex justify-between">
                  <span className="text-gray-700">Net Cash from Financing</span>
                  <span className={`font-bold ${
                    cashFlow.financingCash >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    ${cashFlow.financingCash.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="bg-gray-100 p-4 rounded-lg border-2 border-gray-300">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold text-gray-900">Net Change in Cash</span>
                  <span className="text-xl font-bold text-blue-600">
                    ${(cashFlow.operatingCash + cashFlow.investingCash + cashFlow.financingCash).toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeReport === 'trial-balance' && (
          <div className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6 text-center">
              TRIAL BALANCE
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Account Name
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Debit
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Credit
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {state.accounts.map((account) => (
                    <tr key={account.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {account.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                        {(account.type === 'Asset' || account.type === 'Expense') && account.balance > 0
                          ? `$${account.balance.toLocaleString()}`
                          : '-'
                        }
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-900">
                        {(account.type === 'Liability' || account.type === 'Income' || account.type === 'Equity') && account.balance > 0
                          ? `$${account.balance.toLocaleString()}`
                          : (account.balance < 0 ? `$${Math.abs(account.balance).toLocaleString()}` : '-')
                        }
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-gray-50">
                  <tr className="font-bold">
                    <td className="px-6 py-4 text-sm text-gray-900">TOTALS</td>
                    <td className="px-6 py-4 text-right text-sm text-gray-900">
                      ${state.accounts
                        .filter(acc => (acc.type === 'Asset' || acc.type === 'Expense') && acc.balance > 0)
                        .reduce((sum, acc) => sum + acc.balance, 0)
                        .toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-right text-sm text-gray-900">
                      ${state.accounts
                        .filter(acc => (acc.type === 'Liability' || acc.type === 'Income' || acc.type === 'Equity') && acc.balance > 0)
                        .reduce((sum, acc) => sum + acc.balance, 0)
                        .toLocaleString()}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default FinancialReports;