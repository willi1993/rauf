import React from 'react';
import {
  Home,
  BookOpen,
  Users,
  CreditCard,
  Package,
  BarChart3,
  Settings,
  FileText
} from 'lucide-react';

interface SidebarProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeSection, setActiveSection }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'accounts', label: 'Chart of Accounts', icon: BookOpen },
    { id: 'parties', label: 'Party Management', icon: Users },
    { id: 'vouchers', label: 'Voucher Entry', icon: CreditCard },
    { id: 'transactions', label: 'Transaction History', icon: FileText },
    { id: 'inventory', label: 'Inventory', icon: Package },
    { id: 'reports', label: 'Financial Reports', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="w-64 bg-slate-900 text-white h-full flex flex-col">
      <div className="p-6 border-b border-slate-700">
        <h1 className="text-xl font-bold text-blue-400">FinanceTracker Pro</h1>
        <p className="text-sm text-slate-400 mt-1">Complete Accounting Solution</p>
      </div>
      
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.id}>
                <button
                  onClick={() => setActiveSection(item.id)}
                  className={`w-full flex items-center px-4 py-3 rounded-lg transition-all duration-200 ${
                    activeSection === item.id
                      ? 'bg-blue-600 text-white shadow-lg'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Icon className="w-5 h-5 mr-3" />
                  <span className="font-medium">{item.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-slate-700">
        <div className="bg-slate-800 rounded-lg p-3">
          <p className="text-sm text-slate-400">Version 1.0.0</p>
          <p className="text-xs text-blue-400 mt-1">© 2025 FinanceTracker</p>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;