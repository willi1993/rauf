import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Transaction } from '../../types';
import { Plus, Save, RefreshCw } from 'lucide-react';

const VoucherEntry: React.FC = () => {
  const { state, dispatch } = useApp();
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    voucherType: 'Payment' as Transaction['voucherType'],
    voucherNumber: '',
    description: '',
    amount: 0,
    debitAccount: '',
    creditAccount: '',
    partyId: '',
    reference: ''
  });

  const generateVoucherNumber = (type: Transaction['voucherType']) => {
    const prefix = type.substring(0, 3).toUpperCase();
    const count = state.transactions.filter(t => t.voucherType === type).length + 1;
    return `${prefix}${count.toString().padStart(4, '0')}`;
  };

  const resetForm = () => {
    setFormData({
      date: new Date().toISOString().split('T')[0],
      voucherType: 'Payment',
      voucherNumber: '',
      description: '',
      amount: 0,
      debitAccount: '',
      creditAccount: '',
      partyId: '',
      reference: ''
    });
  };

  const handleVoucherTypeChange = (type: Transaction['voucherType']) => {
    setFormData({
      ...formData,
      voucherType: type,
      voucherNumber: generateVoucherNumber(type)
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newTransaction: Transaction = {
      id: Date.now().toString(),
      date: new Date(formData.date),
      voucherType: formData.voucherType,
      voucherNumber: formData.voucherNumber || generateVoucherNumber(formData.voucherType),
      description: formData.description,
      amount: formData.amount,
      debitAccount: formData.debitAccount,
      creditAccount: formData.creditAccount,
      partyId: formData.partyId || undefined,
      reference: formData.reference || undefined,
      createdAt: new Date()
    };
    
    dispatch({ type: 'ADD_TRANSACTION', payload: newTransaction });
    resetForm();
    alert('Transaction recorded successfully!');
  };

  const voucherTypes = [
    { value: 'Payment', label: 'Payment Voucher', description: 'Cash/Bank payments' },
    { value: 'Receipt', label: 'Receipt Voucher', description: 'Cash/Bank receipts' },
    { value: 'Sales', label: 'Sales Voucher', description: 'Sales transactions' },
    { value: 'Purchase', label: 'Purchase Voucher', description: 'Purchase transactions' },
    { value: 'Journal', label: 'Journal Voucher', description: 'Adjustments & transfers' },
    { value: 'Contra', label: 'Contra Voucher', description: 'Bank to cash transfers' }
  ];

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Voucher Entry</h2>
        <p className="text-gray-600 mt-1">Record financial transactions</p>
      </div>

      {/* Voucher Type Selection */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Voucher Type</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {voucherTypes.map((type) => (
            <button
              key={type.value}
              onClick={() => handleVoucherTypeChange(type.value as Transaction['voucherType'])}
              className={`p-4 rounded-lg border-2 transition-all text-left ${
                formData.voucherType === type.value
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
              }`}
            >
              <h4 className="font-medium text-gray-900">{type.label}</h4>
              <p className="text-sm text-gray-600 mt-1">{type.description}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Transaction Form */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date *
              </label>
              <input
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Voucher Type *
              </label>
              <input
                type="text"
                value={formData.voucherType}
                readOnly
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Voucher Number
              </label>
              <div className="flex">
                <input
                  type="text"
                  value={formData.voucherNumber}
                  onChange={(e) => setFormData({ ...formData, voucherNumber: e.target.value })}
                  placeholder="Auto-generated"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, voucherNumber: generateVoucherNumber(formData.voucherType) })}
                  className="px-3 py-2 bg-gray-100 border border-l-0 border-gray-300 rounded-r-lg hover:bg-gray-200 transition-colors"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description *
            </label>
            <input
              type="text"
              required
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Enter transaction description"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Debit Account *
              </label>
              <select
                required
                value={formData.debitAccount}
                onChange={(e) => setFormData({ ...formData, debitAccount: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Select Debit Account</option>
                {state.accounts.map((account) => (
                  <option key={account.id} value={account.id}>
                    {account.name} ({account.type})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Credit Account *
              </label>
              <select
                required
                value={formData.creditAccount}
                onChange={(e) => setFormData({ ...formData, creditAccount: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Select Credit Account</option>
                {state.accounts.map((account) => (
                  <option key={account.id} value={account.id}>
                    {account.name} ({account.type})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Amount *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) || 0 })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Party (Optional)
              </label>
              <select
                value={formData.partyId}
                onChange={(e) => setFormData({ ...formData, partyId: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Select Party</option>
                {state.parties.map((party) => (
                  <option key={party.id} value={party.id}>
                    {party.name} ({party.type})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Reference (Optional)
            </label>
            <input
              type="text"
              value={formData.reference}
              onChange={(e) => setFormData({ ...formData, reference: e.target.value })}
              placeholder="Check number, invoice reference, etc."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <button
              type="submit"
              className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>Save Transaction</span>
            </button>
            <button
              type="button"
              onClick={resetForm}
              className="flex items-center space-x-2 bg-gray-300 hover:bg-gray-400 text-gray-700 px-6 py-2 rounded-lg transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Reset Form</span>
            </button>
          </div>
        </form>
      </div>

      {/* Recent Transactions Preview */}
      {state.transactions.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Transactions</h3>
          <div className="space-y-3">
            {state.transactions
              .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
              .slice(0, 5)
              .map((txn) => {
                const debitAccount = state.accounts.find(acc => acc.id === txn.debitAccount);
                const creditAccount = state.accounts.find(acc => acc.id === txn.creditAccount);
                const party = txn.partyId ? state.parties.find(p => p.id === txn.partyId) : null;
                
                return (
                  <div key={txn.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{txn.description}</p>
                      <p className="text-xs text-gray-500">
                        {txn.voucherType} • {txn.voucherNumber} • {new Date(txn.date).toLocaleDateString()}
                      </p>
                      <p className="text-xs text-gray-600">
                        Dr: {debitAccount?.name} → Cr: {creditAccount?.name}
                        {party && ` • ${party.name}`}
                      </p>
                    </div>
                    <span className="text-sm font-semibold text-gray-900">
                      ${txn.amount.toLocaleString()}
                    </span>
                  </div>
                );
              })}
          </div>
        </div>
      )}
    </div>
  );
};

export default VoucherEntry;