import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  Package,
  FileText,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';

const Dashboard: React.FC = () => {
  const { state } = useApp();

  const totalAssets = state.accounts
    .filter(acc => acc.type === 'Asset')
    .reduce((sum, acc) => sum + acc.balance, 0);

  const totalLiabilities = state.accounts
    .filter(acc => acc.type === 'Liability')
    .reduce((sum, acc) => sum + acc.balance, 0);

  const totalIncome = state.accounts
    .filter(acc => acc.type === 'Income')
    .reduce((sum, acc) => sum + acc.balance, 0);

  const totalExpenses = state.accounts
    .filter(acc => acc.type === 'Expense')
    .reduce((sum, acc) => sum + acc.balance, 0);

  const netWorth = totalAssets - totalLiabilities;
  const netProfit = totalIncome - totalExpenses;

  const cards = [
    {
      title: 'Total Assets',
      value: totalAssets,
      icon: DollarSign,
      color: 'bg-green-500',
      trend: '+12.5%',
      trendUp: true
    },
    {
      title: 'Net Worth',
      value: netWorth,
      icon: TrendingUp,
      color: 'bg-blue-500',
      trend: '+8.2%',
      trendUp: true
    },
    {
      title: 'Total Parties',
      value: state.parties.length,
      icon: Users,
      color: 'bg-purple-500',
      trend: '+3',
      trendUp: true
    },
    {
      title: 'Inventory Items',
      value: state.inventory.length,
      icon: Package,
      color: 'bg-orange-500',
      trend: '+2',
      trendUp: true
    }
  ];

  const recentTransactions = state.transactions
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  return (
    <div className="p-6 space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{card.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">
                    {typeof card.value === 'number' && card.title.includes('Total') 
                      ? `$${card.value.toLocaleString()}` 
                      : card.value.toLocaleString()}
                  </p>
                  <div className="flex items-center mt-2">
                    {card.trendUp ? (
                      <ArrowUpRight className="w-4 h-4 text-green-500" />
                    ) : (
                      <ArrowDownRight className="w-4 h-4 text-red-500" />
                    )}
                    <span className={`text-sm font-medium ${
                      card.trendUp ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {card.trend}
                    </span>
                    <span className="text-sm text-gray-500 ml-1">vs last month</span>
                  </div>
                </div>
                <div className={`w-12 h-12 ${card.color} rounded-lg flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Financial Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Financial Summary</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
              <span className="text-sm font-medium text-gray-700">Total Income</span>
              <span className="text-lg font-bold text-green-600">${totalIncome.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
              <span className="text-sm font-medium text-gray-700">Total Expenses</span>
              <span className="text-lg font-bold text-red-600">${totalExpenses.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg border-2 border-blue-200">
              <span className="text-sm font-medium text-gray-700">Net Profit/Loss</span>
              <span className={`text-lg font-bold ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                ${netProfit.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Account Types Overview</h3>
          <div className="space-y-3">
            {['Asset', 'Liability', 'Income', 'Expense', 'Equity'].map((type) => {
              const accounts = state.accounts.filter(acc => acc.type === type);
              const total = accounts.reduce((sum, acc) => sum + Math.abs(acc.balance), 0);
              return (
                <div key={type} className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className={`w-3 h-3 rounded-full mr-3 ${
                      type === 'Asset' ? 'bg-green-500' :
                      type === 'Liability' ? 'bg-red-500' :
                      type === 'Income' ? 'bg-blue-500' :
                      type === 'Expense' ? 'bg-orange-500' : 'bg-purple-500'
                    }`}></div>
                    <span className="text-sm font-medium text-gray-700">{type}</span>
                    <span className="text-xs text-gray-500 ml-1">({accounts.length})</span>
                  </div>
                  <span className="text-sm font-semibold text-gray-900">
                    ${total.toLocaleString()}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Recent Activity & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Recent Transactions</h3>
            <FileText className="w-5 h-5 text-gray-400" />
          </div>
          {recentTransactions.length > 0 ? (
            <div className="space-y-3">
              {recentTransactions.map((txn) => (
                <div key={txn.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{txn.description}</p>
                    <p className="text-xs text-gray-500">{txn.voucherType} • {txn.voucherNumber}</p>
                  </div>
                  <span className="text-sm font-semibold text-gray-900">
                    ${txn.amount.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-sm text-gray-500">No transactions recorded yet</p>
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            <button className="flex items-center justify-center p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors">
              <div className="text-center">
                <DollarSign className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                <span className="text-sm font-medium text-blue-700">New Transaction</span>
              </div>
            </button>
            <button className="flex items-center justify-center p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors">
              <div className="text-center">
                <Users className="w-6 h-6 text-green-600 mx-auto mb-2" />
                <span className="text-sm font-medium text-green-700">Add Party</span>
              </div>
            </button>
            <button className="flex items-center justify-center p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors">
              <div className="text-center">
                <Package className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                <span className="text-sm font-medium text-purple-700">Update Inventory</span>
              </div>
            </button>
            <button className="flex items-center justify-center p-4 bg-orange-50 hover:bg-orange-100 rounded-lg transition-colors">
              <div className="text-center">
                <TrendingUp className="w-6 h-6 text-orange-600 mx-auto mb-2" />
                <span className="text-sm font-medium text-orange-700">View Reports</span>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;