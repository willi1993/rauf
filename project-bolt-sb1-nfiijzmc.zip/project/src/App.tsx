import React, { useState } from 'react';
import { AppProvider } from './context/AppContext';
import Sidebar from './components/Layout/Sidebar';
import Header from './components/Layout/Header';
import Dashboard from './components/Dashboard/Dashboard';
import AccountManagement from './components/Accounts/AccountManagement';
import PartyManagement from './components/Parties/PartyManagement';
import VoucherEntry from './components/Transactions/VoucherEntry';
import TransactionHistory from './components/Transactions/TransactionHistory';
import InventoryManagement from './components/Inventory/InventoryManagement';
import FinancialReports from './components/Reports/FinancialReports';

function App() {
  const [activeSection, setActiveSection] = useState('dashboard');

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard />;
      case 'accounts':
        return <AccountManagement />;
      case 'parties':
        return <PartyManagement />;
      case 'vouchers':
        return <VoucherEntry />;
      case 'transactions':
        return <TransactionHistory />;
      case 'inventory':
        return <InventoryManagement />;
      case 'reports':
        return <FinancialReports />;
      case 'settings':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Settings</h2>
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <p className="text-gray-600">Settings panel coming soon...</p>
            </div>
          </div>
        );
      default:
        return <Dashboard />;
    }
  };

  return (
    <AppProvider>
      <div className="flex h-screen bg-gray-100">
        <Sidebar activeSection={activeSection} setActiveSection={setActiveSection} />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header activeSection={activeSection} />
          <main className="flex-1 overflow-x-hidden overflow-y-auto">
            {renderContent()}
          </main>
        </div>
      </div>
    </AppProvider>
  );
}

export default App;